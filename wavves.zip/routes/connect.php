<?php

$conn = mysqli_connect('localhost', 'root', '', 'waves_23');        // make sql db connection
if (!$conn) {
    echo 'Connection Error  ' . mysqli_connect_error();
}

// $conn = mysqli_connect('localhost', 'nscet_webadmin', 'x}2^7Wk^H^.n', 'nscet_waves_23');        // make sql db connection
// if (!$conn) {
//     echo 'Connection Error  ' . mysqli_connect_error();
// }

?>