<?php ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
    <style>
        /*======================
    404 page
=======================*/
        body{
            background-image: url(../public/images/404.jpg);
            background-position: center;
            overflow: hidden;
            width: 100vw;
            height: 100vh;
        }

    </style>


</head>

<body>
    <div style="width: 100vw;display: flex;justify-content: center;margin-top: 32px;">
        <a href="../index.php" class="link_404"><img width="320px" src="../public/images/logos/waves-logo.png" alt=""></a>
    </div>

</body>

</html>